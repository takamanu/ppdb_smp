@extends('layouts/main')

@section('container')
    <h2>Perkembangan Bisnis</h2>
@endsection